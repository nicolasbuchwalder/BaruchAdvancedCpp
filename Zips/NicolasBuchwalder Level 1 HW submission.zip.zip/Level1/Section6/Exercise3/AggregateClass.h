struct AggregateClass {
	int val; char c; double d;
};