#pragma once
class DirectClass
{
private:
	int val;
public:
	DirectClass(int input_val) : val{ input_val } {};
};

