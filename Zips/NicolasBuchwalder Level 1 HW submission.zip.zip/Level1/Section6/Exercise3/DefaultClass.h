#pragma once
class DefaultClass
{
private:
	int val{};
};

