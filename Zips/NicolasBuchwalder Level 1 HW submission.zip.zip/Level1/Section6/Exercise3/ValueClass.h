#pragma once
class ValueClass
{
private:
	int val;
public:
	ValueClass() { val = 0; };
};

