#pragma once
class ListClass
{
private:
	int pos[3];
public:
	ListClass(int x, int y, int z)
		: pos{ x, y ,z } {};
};

