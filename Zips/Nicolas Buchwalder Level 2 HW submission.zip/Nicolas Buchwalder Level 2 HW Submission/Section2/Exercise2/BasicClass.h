// BasicClass.h: just a basic class for testing
// @NicolasBuchwalder for QuantNet/Baruch MFE Advanced C++ course
#pragma once
class BasicClass
{
public:
	BasicClass() {};
};

